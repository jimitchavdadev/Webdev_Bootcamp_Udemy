/* Deno entry point */

export { default } from './dist/index.deno.mjs'
