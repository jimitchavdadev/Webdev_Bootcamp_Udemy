# Contributing to detect-port

- Fork the project, make a change, and send a pull request;
- Have a look at code style now before starting;
- Make sure the tests case (`$ make test`) pass before sending a pull request;
