'use strict';
module.exports = {
	stdin: false,
	stderr: false,
	supportsHyperlink: function () { // eslint-disable-line object-shorthand
		return false;
	}
};
