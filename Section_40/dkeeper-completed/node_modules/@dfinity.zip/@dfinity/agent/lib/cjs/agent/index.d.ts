import { Agent } from './api';
export * from './api';
export * from './http';
export * from './proxy';
export declare function getDefaultAgent(): Agent;
