/**
 *
 * @param label string
 * @returns number representing hashed label
 */
export declare function idlLabelToId(label: string): number;
