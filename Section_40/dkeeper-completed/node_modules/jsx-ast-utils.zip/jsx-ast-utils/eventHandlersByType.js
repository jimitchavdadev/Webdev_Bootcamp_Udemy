module.exports = require('./lib').eventHandlersByType; // eslint-disable-line import/no-unresolved
