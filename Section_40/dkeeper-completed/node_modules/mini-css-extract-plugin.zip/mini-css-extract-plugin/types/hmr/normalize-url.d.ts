declare function _exports(urlString: string): string;
export = _exports;
