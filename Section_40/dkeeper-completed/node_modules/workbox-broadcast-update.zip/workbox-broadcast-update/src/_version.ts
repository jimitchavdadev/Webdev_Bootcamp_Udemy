// @ts-ignore
try{self['workbox:broadcast-update:6.4.2']&&_()}catch(e){}