# @material-ui/styles

You can leverage our styling solution, even if you are not using our components.

## Installation

Install the package in your project directory with:

```sh
// with npm
npm install @material-ui/styles

// with yarn
yarn add @material-ui/styles
```

## Documentation

[The documentation](https://material-ui.com/styles/basics/)
