"use strict";
// @ts-ignore
try {
    self['workbox:streams:6.4.1'] && _();
}
catch (e) { }
