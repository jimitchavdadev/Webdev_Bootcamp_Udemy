// @ts-ignore
try{self['workbox:streams:6.4.2']&&_()}catch(e){}