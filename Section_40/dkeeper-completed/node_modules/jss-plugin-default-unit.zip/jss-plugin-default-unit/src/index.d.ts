import {Plugin} from 'jss'

export type Options = {[key: string]: string}

export default function jssPluginSyntaxDefaultUnit(options?: Options): Plugin
