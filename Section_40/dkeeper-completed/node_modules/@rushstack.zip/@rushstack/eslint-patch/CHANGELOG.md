# Change Log - @rushstack/eslint-patch

This log was last generated on Fri, 05 Nov 2021 15:09:18 GMT and should not be manually modified.

## 1.1.0
Fri, 05 Nov 2021 15:09:18 GMT

### Minor changes

- feat(eslint-patch): Find patch targets independently of disk layout

## 1.0.9
Wed, 27 Oct 2021 00:08:15 GMT

### Patches

- Update the package.json repository field to include the directory property.

## 1.0.8
Wed, 13 Oct 2021 15:09:54 GMT

### Patches

- Add support for ESLint 8.0.0

## 1.0.7
Thu, 23 Sep 2021 00:10:40 GMT

### Patches

- Upgrade the `@types/node` dependency to version to version 12.

## 1.0.6
Fri, 30 Oct 2020 00:10:14 GMT

### Patches

- Update the "modern-module-resolution" patch to support ESLint 7.8.0 and newer

## 1.0.5
Wed, 30 Sep 2020 18:39:17 GMT

### Patches

- Update to build with @rushstack/heft-node-rig

## 1.0.4
Wed, 30 Sep 2020 06:53:53 GMT

### Patches

- Update README.md

## 1.0.3
Wed, 12 Aug 2020 00:10:05 GMT

### Patches

- Updated project to build with Heft

## 1.0.2
Wed, 24 Jun 2020 09:50:48 GMT

### Patches

- Fix an issue with the published file set

## 1.0.1
Wed, 24 Jun 2020 09:04:28 GMT

### Patches

- Initial release

