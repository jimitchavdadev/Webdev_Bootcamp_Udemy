"use strict";
// @ts-ignore
try {
    self['workbox:core:6.4.1'] && _();
}
catch (e) { }
