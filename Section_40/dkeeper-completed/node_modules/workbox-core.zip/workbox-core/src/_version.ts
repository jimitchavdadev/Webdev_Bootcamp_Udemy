// @ts-ignore
try{self['workbox:core:6.4.2']&&_()}catch(e){}