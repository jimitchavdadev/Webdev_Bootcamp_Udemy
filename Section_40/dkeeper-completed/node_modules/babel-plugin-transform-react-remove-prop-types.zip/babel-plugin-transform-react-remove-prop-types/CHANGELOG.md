All notable changes are described on the [Releases](https://github.com/oliviertassinari/babel-plugin-transform-react-remove-prop-types/releases) page.
