module.exports = require('./dist/parse-cst').parse
