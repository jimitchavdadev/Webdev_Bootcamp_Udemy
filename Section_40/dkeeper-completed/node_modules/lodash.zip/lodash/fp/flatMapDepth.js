var convert = require('./convert'),
    func = convert('flatMapDepth', require('../flatMapDepth'));

func.placeholder = require('./placeholder');
module.exports = func;
