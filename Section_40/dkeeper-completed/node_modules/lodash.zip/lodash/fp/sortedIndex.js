var convert = require('./convert'),
    func = convert('sortedIndex', require('../sortedIndex'));

func.placeholder = require('./placeholder');
module.exports = func;
