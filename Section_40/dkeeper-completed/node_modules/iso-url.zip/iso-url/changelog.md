## [0.4.6](https://github.com/hugomrdias/iso-url/compare/v0.4.5...v0.4.6) (2019-01-23)


### Bug Fixes

* revert np to be able to support node 8 ([9477e50](https://github.com/hugomrdias/iso-url/commit/9477e50))



## [0.4.5](https://github.com/hugomrdias/iso-url/compare/v0.4.4...v0.4.5) (2019-01-23)


### Bug Fixes

* fix browser version with delegation and format handling of auth ([fafd253](https://github.com/hugomrdias/iso-url/commit/fafd253))



## [0.4.4](https://github.com/hugomrdias/iso-url/compare/v0.4.3...v0.4.4) (2018-12-15)


### Bug Fixes

* add stuff to npm ([b2ecb35](https://github.com/hugomrdias/iso-url/commit/b2ecb35))



## [0.4.3](https://github.com/hugomrdias/iso-url/compare/v0.4.2...v0.4.3) (2018-12-15)


### Bug Fixes

* fix relative ([fd777aa](https://github.com/hugomrdias/iso-url/commit/fd777aa))



## [0.4.2](https://github.com/hugomrdias/iso-url/compare/v0.4.1...v0.4.2) (2018-12-15)


### Bug Fixes

* add @ to auth in format ([33c8406](https://github.com/hugomrdias/iso-url/commit/33c8406))



## [0.4.1](https://github.com/hugomrdias/iso-url/compare/v0.4.0...v0.4.1) (2018-12-15)


### Bug Fixes

* better support format in the browser ([77070e5](https://github.com/hugomrdias/iso-url/commit/77070e5))
* better support format in the browser ([9c2d83b](https://github.com/hugomrdias/iso-url/commit/9c2d83b))



# [0.4.0](https://github.com/hugomrdias/iso-url/compare/v0.3.0...v0.4.0) (2018-12-15)



# [0.3.0](https://github.com/hugomrdias/iso-url/compare/v0.2.0...v0.3.0) (2018-12-13)


### Features

* support node 8 ([d09fd3c](https://github.com/hugomrdias/iso-url/commit/d09fd3c))



# [0.2.0](https://github.com/hugomrdias/iso-url/compare/v0.1.0...v0.2.0) (2018-12-13)


### Bug Fixes

* fix browser version ([b3b4a9d](https://github.com/hugomrdias/iso-url/commit/b3b4a9d))


### Features

* support format ([dc492ef](https://github.com/hugomrdias/iso-url/commit/dc492ef))



# [0.1.0](https://github.com/hugomrdias/iso-url/compare/v0.0.2...v0.1.0) (2018-12-10)



## [0.0.2](https://github.com/hugomrdias/iso-url/compare/v0.0.1...v0.0.2) (2018-12-06)



## [0.0.1](https://github.com/hugomrdias/iso-url/compare/cc522d6...v0.0.1) (2018-12-06)


### Features

* initial commit ([cc522d6](https://github.com/hugomrdias/iso-url/commit/cc522d6))



