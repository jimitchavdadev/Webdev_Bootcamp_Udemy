const set = require('regenerate')(0x11288);
set.addRange(0x11280, 0x11286).addRange(0x1128A, 0x1128D).addRange(0x1128F, 0x1129D).addRange(0x1129F, 0x112A9);
exports.characters = set;
