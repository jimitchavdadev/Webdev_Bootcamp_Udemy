const set = require('regenerate')();
set.addRange(0x800, 0x82D).addRange(0x830, 0x83E);
exports.characters = set;
