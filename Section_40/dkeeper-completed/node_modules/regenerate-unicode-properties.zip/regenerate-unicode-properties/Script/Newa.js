const set = require('regenerate')();
set.addRange(0x11400, 0x1145B).addRange(0x1145D, 0x11461);
exports.characters = set;
