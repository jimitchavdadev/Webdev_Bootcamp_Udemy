const set = require('regenerate')();
set.addRange(0x14400, 0x14646);
exports.characters = set;
