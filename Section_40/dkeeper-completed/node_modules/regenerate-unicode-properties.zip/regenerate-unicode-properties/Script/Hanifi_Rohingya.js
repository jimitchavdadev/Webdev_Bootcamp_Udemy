const set = require('regenerate')();
set.addRange(0x10D00, 0x10D27).addRange(0x10D30, 0x10D39);
exports.characters = set;
