const set = require('regenerate')();
set.addRange(0x11100, 0x11134).addRange(0x11136, 0x11147);
exports.characters = set;
