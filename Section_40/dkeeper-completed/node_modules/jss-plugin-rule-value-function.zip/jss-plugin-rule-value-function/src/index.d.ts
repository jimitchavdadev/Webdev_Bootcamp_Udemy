import {Plugin} from 'jss'

export default function jssPluginSyntaxRuleValueFunction(): Plugin
