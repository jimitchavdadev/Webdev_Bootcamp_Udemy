// @ts-ignore
try{self['workbox:expiration:6.4.2']&&_()}catch(e){}