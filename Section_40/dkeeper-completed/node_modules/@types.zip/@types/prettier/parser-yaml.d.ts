import { Parser } from './';

declare const parser: {
    parsers: {
        yaml: Parser;
    };
};
export = parser;
