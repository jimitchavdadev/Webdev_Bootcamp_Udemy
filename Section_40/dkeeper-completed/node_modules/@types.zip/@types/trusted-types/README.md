# Installation
> `npm install --save @types/trusted-types`

# Summary
This package contains type definitions for trusted-types (https://github.com/WICG/trusted-types).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/trusted-types.

### Additional Details
 * Last updated: Fri, 02 Jul 2021 19:37:19 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Jakub Vrana](https://github.com/vrana), [Damien Engels](https://github.com/engelsdamien), [Emanuel Tesar](https://github.com/siegrift), and [Bjarki](https://github.com/bjarkler).
