import { EsLintReporterConfiguration } from '../EsLintReporterConfiguration';
import { Reporter } from '../../reporter';
declare function createEsLintReporter(configuration: EsLintReporterConfiguration): Reporter;
export { createEsLintReporter };
