interface FilesMatch {
    files: string[];
    dirs: string[];
    excluded: string[];
    extensions: string[];
}
export { FilesMatch };
