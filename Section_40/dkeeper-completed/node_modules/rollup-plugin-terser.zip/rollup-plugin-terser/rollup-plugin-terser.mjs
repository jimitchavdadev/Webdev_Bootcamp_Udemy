import terserModule from "./rollup-plugin-terser.js";

export const terser = terserModule.terser;
