import {Plugin} from 'jss'

export default function jssPluginVendorPrefixer(): Plugin
