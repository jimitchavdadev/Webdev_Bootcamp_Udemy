# Changes to PostCSS OKLab Function

### 1.0.1 (February 12, 2022)

- Updated `@csstools/postcss-progressive-custom-properties` to `1.1.0`.

### 1.0.0 (February 11, 2022)

- Initial version
