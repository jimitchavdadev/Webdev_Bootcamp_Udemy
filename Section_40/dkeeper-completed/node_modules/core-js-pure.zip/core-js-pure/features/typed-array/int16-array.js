var parent = require('../../actual/typed-array/int16-array');
require('../../features/typed-array/methods');

module.exports = parent;
