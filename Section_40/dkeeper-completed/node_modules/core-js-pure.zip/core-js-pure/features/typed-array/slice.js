var parent = require('../../actual/typed-array/slice');

module.exports = parent;
