var parent = require('../../actual/typed-array/from');

module.exports = parent;
