var parent = require('../../../actual/string/virtual/sup');

module.exports = parent;
