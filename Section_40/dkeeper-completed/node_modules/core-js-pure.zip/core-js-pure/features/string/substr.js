var parent = require('../../actual/string/substr');

module.exports = parent;
