var parent = require('../../actual/string/raw');

module.exports = parent;
