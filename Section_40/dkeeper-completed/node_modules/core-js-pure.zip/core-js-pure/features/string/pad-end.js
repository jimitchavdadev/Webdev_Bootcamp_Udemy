var parent = require('../../actual/string/pad-end');

module.exports = parent;
