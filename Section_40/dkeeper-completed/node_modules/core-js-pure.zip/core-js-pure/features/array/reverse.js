var parent = require('../../actual/array/reverse');

module.exports = parent;
