var parent = require('../../../actual/array/virtual/sort');

module.exports = parent;
