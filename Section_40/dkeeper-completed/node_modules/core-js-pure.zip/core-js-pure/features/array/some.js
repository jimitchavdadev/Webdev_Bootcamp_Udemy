var parent = require('../../actual/array/some');

module.exports = parent;
