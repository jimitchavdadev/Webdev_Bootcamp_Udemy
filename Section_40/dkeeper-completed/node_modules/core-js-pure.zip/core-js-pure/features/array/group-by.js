var parent = require('../../actual/array/group-by');

module.exports = parent;
