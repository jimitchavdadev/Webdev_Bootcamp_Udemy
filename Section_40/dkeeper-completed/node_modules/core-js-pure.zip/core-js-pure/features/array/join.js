var parent = require('../../actual/array/join');

module.exports = parent;
