var parent = require('../../actual/url-search-params');

module.exports = parent;
