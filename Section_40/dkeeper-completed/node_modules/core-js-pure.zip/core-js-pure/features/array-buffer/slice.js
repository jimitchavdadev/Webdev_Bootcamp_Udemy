var parent = require('../../actual/array-buffer/slice');

module.exports = parent;
