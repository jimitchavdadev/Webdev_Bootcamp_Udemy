var parent = require('../../actual/symbol/species');

module.exports = parent;
