var parent = require('../../actual/symbol/match');

module.exports = parent;
