require('../../modules/esnext.math.signbit');
var path = require('../../internals/path');

module.exports = path.Math.signbit;
