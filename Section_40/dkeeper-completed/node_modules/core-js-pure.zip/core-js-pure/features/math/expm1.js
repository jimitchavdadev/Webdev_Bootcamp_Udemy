var parent = require('../../actual/math/expm1');

module.exports = parent;
