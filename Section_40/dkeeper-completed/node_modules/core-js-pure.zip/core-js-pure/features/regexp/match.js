var parent = require('../../actual/regexp/match');

module.exports = parent;
