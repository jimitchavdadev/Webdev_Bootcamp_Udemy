var parent = require('../../actual/data-view');

module.exports = parent;
