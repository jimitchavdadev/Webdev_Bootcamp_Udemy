var parent = require('../../actual/number/is-safe-integer');

module.exports = parent;
