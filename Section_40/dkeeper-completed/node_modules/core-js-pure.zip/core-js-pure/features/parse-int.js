var parent = require('../actual/parse-int');

module.exports = parent;
