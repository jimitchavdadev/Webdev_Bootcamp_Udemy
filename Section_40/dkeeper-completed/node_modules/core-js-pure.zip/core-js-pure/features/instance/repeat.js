var parent = require('../../actual/instance/repeat');

module.exports = parent;
