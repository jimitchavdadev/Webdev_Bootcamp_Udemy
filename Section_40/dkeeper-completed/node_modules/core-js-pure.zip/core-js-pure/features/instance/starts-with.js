var parent = require('../../actual/instance/starts-with');

module.exports = parent;
