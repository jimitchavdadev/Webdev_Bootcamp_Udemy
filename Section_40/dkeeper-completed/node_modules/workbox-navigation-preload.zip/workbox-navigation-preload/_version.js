"use strict";
// @ts-ignore
try {
    self['workbox:navigation-preload:6.4.1'] && _();
}
catch (e) { }
