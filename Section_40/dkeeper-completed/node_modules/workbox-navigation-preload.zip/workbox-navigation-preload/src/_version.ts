// @ts-ignore
try{self['workbox:navigation-preload:6.4.2']&&_()}catch(e){}