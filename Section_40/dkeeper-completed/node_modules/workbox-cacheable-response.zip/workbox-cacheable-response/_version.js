"use strict";
// @ts-ignore
try {
    self['workbox:cacheable-response:6.4.1'] && _();
}
catch (e) { }
