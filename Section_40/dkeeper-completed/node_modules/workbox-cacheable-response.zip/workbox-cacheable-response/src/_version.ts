// @ts-ignore
try{self['workbox:cacheable-response:6.4.2']&&_()}catch(e){}