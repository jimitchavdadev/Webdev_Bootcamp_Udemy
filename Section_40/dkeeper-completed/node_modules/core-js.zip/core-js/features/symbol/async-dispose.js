require('../../modules/esnext.symbol.async-dispose');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('asyncDispose');
