var parent = require('../actual/atob');

module.exports = parent;
