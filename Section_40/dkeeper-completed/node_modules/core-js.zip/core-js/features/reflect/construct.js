var parent = require('../../actual/reflect/construct');

module.exports = parent;
