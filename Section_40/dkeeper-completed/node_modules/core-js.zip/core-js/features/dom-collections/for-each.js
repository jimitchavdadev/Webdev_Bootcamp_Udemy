var parent = require('../../actual/dom-collections/for-each');

module.exports = parent;
