var parent = require('../../actual/typed-array/map');

module.exports = parent;
