var parent = require('../../actual/number/parse-int');

module.exports = parent;
