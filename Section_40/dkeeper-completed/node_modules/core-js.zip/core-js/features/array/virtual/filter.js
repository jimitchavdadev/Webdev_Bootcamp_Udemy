var parent = require('../../../actual/array/virtual/filter');

module.exports = parent;
