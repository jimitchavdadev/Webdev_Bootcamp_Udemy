var parent = require('../../../actual/array/virtual/reduce-right');

module.exports = parent;
