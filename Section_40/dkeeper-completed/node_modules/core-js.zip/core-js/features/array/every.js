var parent = require('../../actual/array/every');

module.exports = parent;
