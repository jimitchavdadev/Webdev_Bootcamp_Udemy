var parent = require('../../actual/array/index-of');

module.exports = parent;
