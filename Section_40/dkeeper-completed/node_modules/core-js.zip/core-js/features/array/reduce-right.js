var parent = require('../../actual/array/reduce-right');

module.exports = parent;
