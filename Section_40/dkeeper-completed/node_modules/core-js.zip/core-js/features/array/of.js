var parent = require('../../actual/array/of');

module.exports = parent;
