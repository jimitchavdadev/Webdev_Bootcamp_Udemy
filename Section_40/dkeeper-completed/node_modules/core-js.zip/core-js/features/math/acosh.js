var parent = require('../../actual/math/acosh');

module.exports = parent;
