var parent = require('../../actual/date/now');

module.exports = parent;
