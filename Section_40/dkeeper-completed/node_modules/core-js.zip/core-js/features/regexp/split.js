var parent = require('../../actual/regexp/split');

module.exports = parent;
