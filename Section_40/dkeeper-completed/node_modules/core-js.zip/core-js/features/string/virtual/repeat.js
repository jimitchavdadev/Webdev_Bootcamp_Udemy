var parent = require('../../../actual/string/virtual/repeat');

module.exports = parent;
