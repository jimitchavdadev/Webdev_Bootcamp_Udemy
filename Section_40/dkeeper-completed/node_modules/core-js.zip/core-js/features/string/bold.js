var parent = require('../../actual/string/bold');

module.exports = parent;
