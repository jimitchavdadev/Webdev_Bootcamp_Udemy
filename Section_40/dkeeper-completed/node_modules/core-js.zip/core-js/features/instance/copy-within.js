var parent = require('../../actual/instance/copy-within');

module.exports = parent;
