var parent = require('../../actual/instance/trim');

module.exports = parent;
