var parent = require('../../actual/instance/filter');

module.exports = parent;
