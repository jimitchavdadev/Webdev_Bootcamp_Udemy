# axobject-query Change Log

## 1.0.1

- Changed label from structure to widget
- Added the CHANGELOG file

## 2.0.1

- Add NPM and Watchman configs

## 2.1.0

- b436e56 (origin/update-dependencies, update-dependencies) Update dependencies; ESLint to 6
- c157720 Fixes for select and datalist

## 2.1.1

- Bumping the version to see if Travis will run green on the master branch

## 2.1.2

- a1c5ef9 Updated the Copyright to 2020 for A11yance
- 5c5e04d Remove Peer Dependency to ESLint
- ec1b53b Remove dependencies on @babel/runtime and @babel/runtime-corejs3

## 2.2.0

- 9b9db89 Add the summary element as a related concept in DisclosureTriangleRole
- 7ac02af Fix the build script for the src files
- 56e0765 Fix permissions on files from 755 to 644
