'use strict';
require('./warnAboutDeprecatedCJSRequire.js')('createHashHistory');
module.exports = require('./index.js').createHashHistory;
