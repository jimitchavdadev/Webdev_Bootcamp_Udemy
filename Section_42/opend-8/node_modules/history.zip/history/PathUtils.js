'use strict';
require('./warnAboutDeprecatedCJSRequire.js')('PathUtils');
module.exports = require('./index.js').PathUtils;
