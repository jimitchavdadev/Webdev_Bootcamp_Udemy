'use strict';
require('./warnAboutDeprecatedCJSRequire.js')('createTransitionManager');
module.exports = require('./index.js').createTransitionManager;
