/**
 * A helper for creating a shadowRoot on an element.
 */
export declare const renderShadowRoot: (result: unknown, element: Element) => void;
//# sourceMappingURL=shadow-root.d.ts.map
