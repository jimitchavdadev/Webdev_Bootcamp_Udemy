var convert = require('./convert'),
    func = convert('join', require('../join'));

func.placeholder = require('./placeholder');
module.exports = func;
