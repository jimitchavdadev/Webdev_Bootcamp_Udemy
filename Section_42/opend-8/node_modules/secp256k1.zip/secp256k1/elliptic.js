module.exports = require('./lib')(require('./lib/elliptic'))
