import useUpdateImmediateEffect from './useUpdateImmediateEffect';
export default useUpdateImmediateEffect;
