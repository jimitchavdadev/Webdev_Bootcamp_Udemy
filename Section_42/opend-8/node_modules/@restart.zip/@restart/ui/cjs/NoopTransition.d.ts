/// <reference types="react" />
import { TransitionProps } from './types';
declare function NoopTransition({ children, in: inProp, mountOnEnter, unmountOnExit, }: TransitionProps): import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>> | null;
export default NoopTransition;
