export default function useScrollParent(element: null | Element): Element | Document | null | undefined;
