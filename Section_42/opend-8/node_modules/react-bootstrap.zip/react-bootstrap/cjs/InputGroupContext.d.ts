import * as React from 'react';
declare const context: React.Context<unknown>;
export default context;
