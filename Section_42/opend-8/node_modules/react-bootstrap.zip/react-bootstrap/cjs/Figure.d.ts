/// <reference types="react" />
declare const _default: import("./helpers").BsPrefixRefForwardingComponent<"figure", unknown> & {
    Image: import("react").ForwardRefExoticComponent<import("./Image").ImageProps & import("react").RefAttributes<HTMLImageElement>>;
    Caption: import("./helpers").BsPrefixRefForwardingComponent<"figcaption", unknown>;
};
export default _default;
