import * as React from 'react';
export interface AccordionItemContextValue {
    eventKey: string;
}
declare const context: React.Context<AccordionItemContextValue>;
export default context;
