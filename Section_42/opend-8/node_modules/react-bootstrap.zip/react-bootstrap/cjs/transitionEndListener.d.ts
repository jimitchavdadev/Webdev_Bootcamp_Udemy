export default function transitionEndListener(element: HTMLElement, handler: (e: TransitionEvent) => void): void;
