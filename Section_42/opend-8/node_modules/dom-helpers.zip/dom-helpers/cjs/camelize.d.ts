export default function camelize(string: string): string;
