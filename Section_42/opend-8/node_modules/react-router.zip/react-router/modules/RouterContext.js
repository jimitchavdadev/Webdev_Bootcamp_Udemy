import createNamedContext from "./createNameContext";

const context = /*#__PURE__*/ createNamedContext("Router");
export default context;
