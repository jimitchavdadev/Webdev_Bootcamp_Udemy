declare class ConfigTestCommand {
    apply(cli: any): Promise<void>;
}
export default ConfigTestCommand;
