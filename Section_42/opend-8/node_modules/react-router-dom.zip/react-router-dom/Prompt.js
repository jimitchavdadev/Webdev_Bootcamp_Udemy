"use strict";
require("./warnAboutDeprecatedCJSRequire")("Prompt");
module.exports = require("./index.js").Prompt;
