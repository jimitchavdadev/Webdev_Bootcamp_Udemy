"use strict";
require("./warnAboutDeprecatedCJSRequire")("HashRouter");
module.exports = require("./index.js").HashRouter;
