"use strict";
require("./warnAboutDeprecatedCJSRequire")("BrowserRouter");
module.exports = require("./index.js").BrowserRouter;
