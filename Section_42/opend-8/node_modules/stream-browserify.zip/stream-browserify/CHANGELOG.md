# stream-browserify change log

All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](http://semver.org/).

## 3.0.0
* Upgrade to `readable-stream` 3. For breaking changes, see the [readable-stream notes](https://github.com/nodejs/readable-stream#version-3xx).
