# Installation
> `npm install --save @types/warning`

# Summary
This package contains type definitions for warning (https://github.com/BerkeleyTrue/warning).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/warning

Additional Details
 * Last updated: Thu, 01 Dec 2016 00:24:42 GMT
 * File structure: ProperModule
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: warning

# Credits
These definitions were written by Chi Vinh Le <https://github.com/cvle>.
