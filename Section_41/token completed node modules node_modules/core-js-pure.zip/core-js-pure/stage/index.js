var proposals = require('./pre');

module.exports = proposals;
