var parent = require('../../actual/string/trim-end');

module.exports = parent;
