var parent = require('../../../actual/string/virtual/trim');

module.exports = parent;
