var parent = require('../../../actual/string/virtual/pad-end');

module.exports = parent;
