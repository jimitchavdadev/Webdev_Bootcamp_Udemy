var parent = require('../../../actual/string/virtual/pad-start');

module.exports = parent;
