var parent = require('../../actual/symbol/replace');

module.exports = parent;
