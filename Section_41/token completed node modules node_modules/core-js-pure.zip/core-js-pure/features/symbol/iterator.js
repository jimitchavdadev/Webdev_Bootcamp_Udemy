var parent = require('../../actual/symbol/iterator');

module.exports = parent;
