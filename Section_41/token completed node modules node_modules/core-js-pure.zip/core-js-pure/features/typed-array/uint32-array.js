var parent = require('../../actual/typed-array/uint32-array');
require('../../features/typed-array/methods');

module.exports = parent;
