var parent = require('../../actual/typed-array/for-each');

module.exports = parent;
