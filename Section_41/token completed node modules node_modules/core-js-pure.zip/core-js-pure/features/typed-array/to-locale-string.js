var parent = require('../../actual/typed-array/to-locale-string');

module.exports = parent;
