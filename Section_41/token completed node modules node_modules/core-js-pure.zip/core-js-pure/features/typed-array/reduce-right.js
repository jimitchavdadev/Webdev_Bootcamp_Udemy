var parent = require('../../actual/typed-array/reduce-right');

module.exports = parent;
