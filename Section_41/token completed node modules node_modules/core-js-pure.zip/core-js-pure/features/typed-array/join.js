var parent = require('../../actual/typed-array/join');

module.exports = parent;
