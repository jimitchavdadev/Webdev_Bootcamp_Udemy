var parent = require('../../actual/typed-array/reduce');

module.exports = parent;
