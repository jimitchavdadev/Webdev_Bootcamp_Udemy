var parent = require('../../actual/typed-array/int32-array');
require('../../features/typed-array/methods');

module.exports = parent;
