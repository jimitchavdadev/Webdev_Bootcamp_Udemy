var parent = require('../../actual/typed-array/some');

module.exports = parent;
