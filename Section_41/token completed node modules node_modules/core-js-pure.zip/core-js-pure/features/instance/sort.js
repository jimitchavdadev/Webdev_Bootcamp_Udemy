var parent = require('../../actual/instance/sort');

module.exports = parent;
