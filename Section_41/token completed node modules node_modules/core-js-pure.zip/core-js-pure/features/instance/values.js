var parent = require('../../actual/instance/values');

module.exports = parent;
