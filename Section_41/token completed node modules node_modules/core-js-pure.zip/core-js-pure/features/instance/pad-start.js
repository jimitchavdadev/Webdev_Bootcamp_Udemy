var parent = require('../../actual/instance/pad-start');

module.exports = parent;
