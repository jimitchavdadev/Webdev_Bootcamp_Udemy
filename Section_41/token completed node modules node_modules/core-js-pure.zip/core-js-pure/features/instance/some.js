var parent = require('../../actual/instance/some');

module.exports = parent;
