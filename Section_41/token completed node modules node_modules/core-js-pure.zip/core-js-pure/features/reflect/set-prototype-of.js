var parent = require('../../actual/reflect/set-prototype-of');

module.exports = parent;
