var parent = require('../../actual/math/imul');

module.exports = parent;
