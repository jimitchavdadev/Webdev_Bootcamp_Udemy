var parent = require('../../actual/math/trunc');

module.exports = parent;
