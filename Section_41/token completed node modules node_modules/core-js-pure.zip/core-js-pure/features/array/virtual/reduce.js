var parent = require('../../../actual/array/virtual/reduce');

module.exports = parent;
