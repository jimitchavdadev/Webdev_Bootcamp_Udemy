var parent = require('../../../actual/array/virtual/copy-within');

module.exports = parent;
