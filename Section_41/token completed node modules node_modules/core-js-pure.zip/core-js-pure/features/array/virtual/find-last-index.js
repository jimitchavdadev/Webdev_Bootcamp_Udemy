var parent = require('../../../actual/array/virtual/find-last-index');

module.exports = parent;
