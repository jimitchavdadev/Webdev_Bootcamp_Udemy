var parent = require('../../../actual/array/virtual/slice');

module.exports = parent;
