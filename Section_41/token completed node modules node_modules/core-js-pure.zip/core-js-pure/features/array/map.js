var parent = require('../../actual/array/map');

module.exports = parent;
