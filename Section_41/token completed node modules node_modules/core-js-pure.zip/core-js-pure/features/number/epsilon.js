var parent = require('../../actual/number/epsilon');

module.exports = parent;
