var parent = require('../../actual/number/max-safe-integer');

module.exports = parent;
