var parent = require('../../actual/number/is-integer');

module.exports = parent;
