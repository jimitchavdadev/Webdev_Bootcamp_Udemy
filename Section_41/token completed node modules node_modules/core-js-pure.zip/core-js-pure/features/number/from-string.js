require('../../modules/esnext.number.from-string');
var path = require('../../internals/path');

module.exports = path.Number.fromString;
