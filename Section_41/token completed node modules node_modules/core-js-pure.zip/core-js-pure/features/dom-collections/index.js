var parent = require('../../actual/dom-collections');

module.exports = parent;
