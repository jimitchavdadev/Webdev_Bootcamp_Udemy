var parent = require('../actual/escape');

module.exports = parent;
