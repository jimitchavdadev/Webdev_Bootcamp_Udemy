var parent = require('../../actual/url');

module.exports = parent;
