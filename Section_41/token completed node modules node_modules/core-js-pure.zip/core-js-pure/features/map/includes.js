require('../../modules/es.map');
require('../../modules/esnext.map.includes');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Map', 'includes');
