declare const _exports: (props: import('postcss').Declaration[], includeCustomProps?: boolean | undefined) => boolean;
export = _exports;
