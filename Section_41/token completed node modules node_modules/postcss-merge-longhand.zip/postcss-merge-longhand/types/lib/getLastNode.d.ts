declare const _exports: (rule: import('postcss').AnyNode[], prop: string) => import('postcss').Declaration;
export = _exports;
