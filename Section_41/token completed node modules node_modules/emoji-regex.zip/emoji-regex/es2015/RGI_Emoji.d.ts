declare module 'emoji-regex/es2015/RGI_Emoji' {
  function emojiRegex(): RegExp;

  export = emojiRegex;
}
