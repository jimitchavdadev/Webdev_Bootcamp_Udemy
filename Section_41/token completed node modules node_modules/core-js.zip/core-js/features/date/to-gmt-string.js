var parent = require('../../actual/date/to-gmt-string');

module.exports = parent;
