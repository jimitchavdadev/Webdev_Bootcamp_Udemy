var parent = require('../../actual/array-buffer/constructor');

module.exports = parent;
