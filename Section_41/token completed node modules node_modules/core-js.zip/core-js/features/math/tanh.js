var parent = require('../../actual/math/tanh');

module.exports = parent;
