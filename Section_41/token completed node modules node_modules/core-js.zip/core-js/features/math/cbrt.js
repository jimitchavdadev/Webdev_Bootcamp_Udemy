var parent = require('../../actual/math/cbrt');

module.exports = parent;
