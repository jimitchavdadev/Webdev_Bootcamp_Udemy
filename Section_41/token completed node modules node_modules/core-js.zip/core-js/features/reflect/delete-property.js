var parent = require('../../actual/reflect/delete-property');

module.exports = parent;
