require('../../modules/es.object.to-string');
require('../../modules/esnext.iterator.constructor');
require('../../modules/esnext.iterator.as-indexed-pairs');

var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Iterator', 'asIndexedPairs');

