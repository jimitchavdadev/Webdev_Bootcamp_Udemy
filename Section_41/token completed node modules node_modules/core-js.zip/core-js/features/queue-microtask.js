var parent = require('../actual/queue-microtask');

module.exports = parent;
