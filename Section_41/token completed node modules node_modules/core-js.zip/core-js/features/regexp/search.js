var parent = require('../../actual/regexp/search');

module.exports = parent;
