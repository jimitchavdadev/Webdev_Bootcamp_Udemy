require('../../modules/es.object.to-string');
require('../../modules/esnext.bigint.range');
var BigInt = require('../../internals/path').BigInt;

module.exports = BigInt;
