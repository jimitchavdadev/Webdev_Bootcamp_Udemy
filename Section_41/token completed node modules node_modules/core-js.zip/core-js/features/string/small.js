var parent = require('../../actual/string/small');

module.exports = parent;
