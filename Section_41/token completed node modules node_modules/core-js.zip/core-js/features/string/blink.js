var parent = require('../../actual/string/blink');

module.exports = parent;
