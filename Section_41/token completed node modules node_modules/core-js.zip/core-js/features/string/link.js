var parent = require('../../actual/string/link');

module.exports = parent;
