var parent = require('../../actual/string/replace');

module.exports = parent;
