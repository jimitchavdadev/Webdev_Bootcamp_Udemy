var parent = require('../../actual/string/split');

module.exports = parent;
