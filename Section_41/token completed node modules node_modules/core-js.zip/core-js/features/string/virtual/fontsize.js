var parent = require('../../../actual/string/virtual/fontsize');

module.exports = parent;
