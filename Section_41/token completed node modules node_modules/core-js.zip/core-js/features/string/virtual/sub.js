var parent = require('../../../actual/string/virtual/sub');

module.exports = parent;
