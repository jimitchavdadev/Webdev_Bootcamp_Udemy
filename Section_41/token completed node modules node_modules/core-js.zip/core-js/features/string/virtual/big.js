var parent = require('../../../actual/string/virtual/big');

module.exports = parent;
