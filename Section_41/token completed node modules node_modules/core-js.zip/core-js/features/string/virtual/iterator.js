var parent = require('../../../actual/string/virtual/iterator');

module.exports = parent;
