var parent = require('../../actual/typed-array/uint8-clamped-array');
require('../../features/typed-array/methods');

module.exports = parent;
