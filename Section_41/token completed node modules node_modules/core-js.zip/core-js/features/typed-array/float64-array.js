var parent = require('../../actual/typed-array/float64-array');
require('../../features/typed-array/methods');

module.exports = parent;
