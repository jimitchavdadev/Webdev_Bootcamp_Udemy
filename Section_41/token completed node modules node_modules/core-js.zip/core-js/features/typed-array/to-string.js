var parent = require('../../actual/typed-array/to-string');

module.exports = parent;
