var parent = require('../../actual/typed-array/index-of');

module.exports = parent;
