var parent = require('../../actual/typed-array/find-last-index');

module.exports = parent;
