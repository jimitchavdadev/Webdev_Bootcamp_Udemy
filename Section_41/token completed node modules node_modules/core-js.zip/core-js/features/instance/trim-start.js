var parent = require('../../actual/instance/trim-start');

module.exports = parent;
