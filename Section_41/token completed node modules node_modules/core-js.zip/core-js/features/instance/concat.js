var parent = require('../../actual/instance/concat');

module.exports = parent;
