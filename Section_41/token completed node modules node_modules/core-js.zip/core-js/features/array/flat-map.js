var parent = require('../../actual/array/flat-map');

module.exports = parent;
