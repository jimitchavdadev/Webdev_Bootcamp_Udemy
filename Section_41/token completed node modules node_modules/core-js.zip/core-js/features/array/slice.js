var parent = require('../../actual/array/slice');

module.exports = parent;
