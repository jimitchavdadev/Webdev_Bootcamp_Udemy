var parent = require('../../actual/array/filter');

module.exports = parent;
