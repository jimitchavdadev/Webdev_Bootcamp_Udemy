var parent = require('../../../actual/array/virtual/group-by-to-map');

module.exports = parent;
