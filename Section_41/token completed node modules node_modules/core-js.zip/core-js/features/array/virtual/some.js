var parent = require('../../../actual/array/virtual/some');

module.exports = parent;
