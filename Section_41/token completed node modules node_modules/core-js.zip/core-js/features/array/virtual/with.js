require('../../../modules/esnext.array.with');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array')['with'];
