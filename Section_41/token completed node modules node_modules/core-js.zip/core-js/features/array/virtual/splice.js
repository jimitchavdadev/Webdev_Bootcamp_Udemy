var parent = require('../../../actual/array/virtual/splice');

module.exports = parent;
