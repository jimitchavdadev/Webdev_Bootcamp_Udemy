var parent = require('../../../actual/array/virtual');
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.array.at');
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.array.filter-out');
require('../../../modules/esnext.array.filter-reject');
require('../../../modules/esnext.array.to-reversed');
require('../../../modules/esnext.array.to-sorted');
require('../../../modules/esnext.array.to-spliced');
require('../../../modules/esnext.array.unique-by');
require('../../../modules/esnext.array.with');

module.exports = parent;
