var parent = require('../../../actual/number/virtual');

module.exports = parent;
