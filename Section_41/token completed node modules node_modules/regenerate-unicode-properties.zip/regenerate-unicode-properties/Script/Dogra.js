const set = require('regenerate')();
set.addRange(0x11800, 0x1183B);
exports.characters = set;
