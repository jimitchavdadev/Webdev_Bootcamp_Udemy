const set = require('regenerate')();
set.addRange(0x10C00, 0x10C48);
exports.characters = set;
