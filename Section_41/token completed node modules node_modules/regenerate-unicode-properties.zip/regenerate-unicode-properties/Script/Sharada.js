const set = require('regenerate')();
set.addRange(0x11180, 0x111DF);
exports.characters = set;
