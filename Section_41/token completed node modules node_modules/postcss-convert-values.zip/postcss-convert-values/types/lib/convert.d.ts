declare function _exports(number: number, unit: string, { time, length, angle }: {
    time?: boolean;
    length?: boolean;
    angle?: boolean;
}): string;
export = _exports;
