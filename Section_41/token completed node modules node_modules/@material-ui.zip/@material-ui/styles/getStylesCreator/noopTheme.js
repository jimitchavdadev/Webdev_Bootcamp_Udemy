"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// We use the same empty object to ref count the styles that don't need a theme object.
var noopTheme = {};
var _default = noopTheme;
exports.default = _default;