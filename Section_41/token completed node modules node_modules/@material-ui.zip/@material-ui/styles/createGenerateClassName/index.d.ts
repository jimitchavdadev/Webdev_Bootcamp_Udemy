export { default } from './createGenerateClassName';
export * from './createGenerateClassName';
