"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.gridArea = exports.gridTemplateAreas = exports.gridTemplateRows = exports.gridTemplateColumns = exports.gridAutoRows = exports.gridAutoColumns = exports.gridAutoFlow = exports.gridRow = exports.gridColumn = exports.gridRowGap = exports.gridColumnGap = exports.gridGap = void 0;

var _style = _interopRequireDefault(require("./style"));

var _compose = _interopRequireDefault(require("./compose"));

var gridGap = (0, _style.default)({
  prop: 'gridGap'
});
exports.gridGap = gridGap;
var gridColumnGap = (0, _style.default)({
  prop: 'gridColumnGap'
});
exports.gridColumnGap = gridColumnGap;
var gridRowGap = (0, _style.default)({
  prop: 'gridRowGap'
});
exports.gridRowGap = gridRowGap;
var gridColumn = (0, _style.default)({
  prop: 'gridColumn'
});
exports.gridColumn = gridColumn;
var gridRow = (0, _style.default)({
  prop: 'gridRow'
});
exports.gridRow = gridRow;
var gridAutoFlow = (0, _style.default)({
  prop: 'gridAutoFlow'
});
exports.gridAutoFlow = gridAutoFlow;
var gridAutoColumns = (0, _style.default)({
  prop: 'gridAutoColumns'
});
exports.gridAutoColumns = gridAutoColumns;
var gridAutoRows = (0, _style.default)({
  prop: 'gridAutoRows'
});
exports.gridAutoRows = gridAutoRows;
var gridTemplateColumns = (0, _style.default)({
  prop: 'gridTemplateColumns'
});
exports.gridTemplateColumns = gridTemplateColumns;
var gridTemplateRows = (0, _style.default)({
  prop: 'gridTemplateRows'
});
exports.gridTemplateRows = gridTemplateRows;
var gridTemplateAreas = (0, _style.default)({
  prop: 'gridTemplateAreas'
});
exports.gridTemplateAreas = gridTemplateAreas;
var gridArea = (0, _style.default)({
  prop: 'gridArea'
});
exports.gridArea = gridArea;
var grid = (0, _compose.default)(gridGap, gridColumnGap, gridRowGap, gridColumn, gridRow, gridAutoFlow, gridAutoColumns, gridAutoRows, gridTemplateColumns, gridTemplateRows, gridTemplateAreas, gridArea);
var _default = grid;
exports.default = _default;