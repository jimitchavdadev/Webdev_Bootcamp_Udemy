export default ESLintError;
declare class ESLintError extends Error {}
