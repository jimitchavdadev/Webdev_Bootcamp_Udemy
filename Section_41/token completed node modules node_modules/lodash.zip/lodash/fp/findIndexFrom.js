var convert = require('./convert'),
    func = convert('findIndexFrom', require('../findIndex'));

func.placeholder = require('./placeholder');
module.exports = func;
