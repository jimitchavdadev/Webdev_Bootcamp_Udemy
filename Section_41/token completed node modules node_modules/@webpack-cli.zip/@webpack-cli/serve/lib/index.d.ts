declare class ServeCommand {
    apply(cli: any): Promise<void>;
}
export default ServeCommand;
