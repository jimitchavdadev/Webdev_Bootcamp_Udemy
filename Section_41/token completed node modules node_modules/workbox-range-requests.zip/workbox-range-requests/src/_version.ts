// @ts-ignore
try{self['workbox:range-requests:6.5.0']&&_()}catch(e){}