"use strict";
// @ts-ignore
try {
    self['workbox:range-requests:6.4.2'] && _();
}
catch (e) { }
