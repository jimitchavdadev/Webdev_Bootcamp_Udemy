// @ts-ignore
try{self['workbox:recipes:6.5.0']&&_()}catch(e){}