# full-cbor
Encode and decode CBOR documents, with compatibility and control for all subtypes
