// @ts-ignore
try{self['workbox:expiration:6.5.0']&&_()}catch(e){}