'use strict';
const rawCache = require('./rawCache.js');
const getArguments = require('./getArguments.js');
const sameParent = require('./sameParent.js');

module.exports = { rawCache, getArguments, sameParent };
