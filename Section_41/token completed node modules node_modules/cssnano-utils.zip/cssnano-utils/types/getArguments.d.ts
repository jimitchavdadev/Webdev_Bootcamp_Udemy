declare function _exports(node: import('postcss-value-parser').ParsedValue | import('postcss-value-parser').FunctionNode): import('postcss-value-parser').Node[][];
export = _exports;
