// @ts-ignore
try{self['workbox:core:6.5.0']&&_()}catch(e){}