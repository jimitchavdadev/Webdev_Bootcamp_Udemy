export interface Config {
    disabled: boolean;
}

declare const config: Config;
export default config;
