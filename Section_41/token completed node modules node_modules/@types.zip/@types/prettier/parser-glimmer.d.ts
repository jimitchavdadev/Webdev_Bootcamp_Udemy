import { Parser } from './';

declare const parser: {
    parsers: {
        glimmer: Parser;
    };
};
export = parser;
