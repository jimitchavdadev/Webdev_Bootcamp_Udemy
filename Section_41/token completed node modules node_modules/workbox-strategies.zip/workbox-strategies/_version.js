"use strict";
// @ts-ignore
try {
    self['workbox:strategies:6.4.2'] && _();
}
catch (e) { }
