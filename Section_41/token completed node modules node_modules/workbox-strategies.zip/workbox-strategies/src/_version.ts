// @ts-ignore
try{self['workbox:strategies:6.5.0']&&_()}catch(e){}