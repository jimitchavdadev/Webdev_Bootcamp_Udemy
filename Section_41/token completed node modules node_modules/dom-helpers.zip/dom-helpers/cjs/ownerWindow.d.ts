/**
 * Returns the owner window of a given element.
 *
 * @param node the element
 */
export default function ownerWindow(node?: Element): Window;
