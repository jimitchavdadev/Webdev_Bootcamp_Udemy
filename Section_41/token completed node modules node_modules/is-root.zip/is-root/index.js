'use strict';

module.exports = () => process.getuid && process.getuid() === 0;
