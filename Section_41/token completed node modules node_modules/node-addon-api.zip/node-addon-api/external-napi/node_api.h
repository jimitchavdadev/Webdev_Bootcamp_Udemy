#ifndef EXTERNAL_NODE_API_H_
#define EXTERNAL_NODE_API_H_

#define EXTERNAL_NAPI
#include "../src/node_api.h"

#endif
