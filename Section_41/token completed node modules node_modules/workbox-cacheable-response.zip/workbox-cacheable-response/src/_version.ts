// @ts-ignore
try{self['workbox:cacheable-response:6.5.0']&&_()}catch(e){}