import webpack from 'webpack';
import { ForkTsCheckerWebpackPluginState } from '../ForkTsCheckerWebpackPluginState';
declare function tapAfterEnvironmentToPatchWatching(compiler: webpack.Compiler, state: ForkTsCheckerWebpackPluginState): void;
export { tapAfterEnvironmentToPatchWatching };
