"use strict";
// @ts-ignore
try {
    self['workbox:precaching:6.4.2'] && _();
}
catch (e) { }
