// @ts-ignore
try{self['workbox:precaching:6.5.0']&&_()}catch(e){}