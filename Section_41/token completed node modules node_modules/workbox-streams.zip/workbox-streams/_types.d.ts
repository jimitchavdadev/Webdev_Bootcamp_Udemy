import './_version.js';
export declare type StreamSource = Response | ReadableStream | BodyInit;
/**
 * @typedef {Response|ReadableStream|BodyInit} StreamSource
 * @memberof workbox-streams
 */
