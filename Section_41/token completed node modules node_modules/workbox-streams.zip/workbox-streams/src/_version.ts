// @ts-ignore
try{self['workbox:streams:6.5.0']&&_()}catch(e){}