"use strict";
// @ts-ignore
try {
    self['workbox:google-analytics:6.4.2'] && _();
}
catch (e) { }
