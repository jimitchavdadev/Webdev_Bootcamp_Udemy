

require('c').hello().goodbye()
require('b').hello()
require('a')
