export {};
//# sourceMappingURL=template_polyfill_test.d.ts.map
