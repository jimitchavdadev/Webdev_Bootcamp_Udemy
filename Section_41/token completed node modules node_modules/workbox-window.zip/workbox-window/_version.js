"use strict";
// @ts-ignore
try {
    self['workbox:window:6.4.2'] && _();
}
catch (e) { }
