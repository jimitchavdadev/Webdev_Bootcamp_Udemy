declare const _default: ({ IDL }: {
    IDL: any;
}) => any;
/**
 * This file is generated from the candid for asset management.
 */
export default _default;
