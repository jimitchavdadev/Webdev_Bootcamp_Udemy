declare function _exports(parsed: import('postcss-value-parser').ParsedValue): string;
export = _exports;
