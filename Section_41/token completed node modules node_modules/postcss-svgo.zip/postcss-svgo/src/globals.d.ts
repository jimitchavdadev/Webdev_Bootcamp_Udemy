declare var URL: typeof import('url').URL;
